## `nf-core pipelines lint` overall result: Passed :white_check_mark: :warning:

Posted for pipeline commit bfdfe70

```diff
+| ✅ 153 tests passed       |+
#| ❔  38 tests were ignored |#
#| ❔   1 tests had warnings |#
!| ❗   2 tests had warnings |!
```

<details>

### :heavy_exclamation_mark: Test warnings:

* [pipeline_name_conventions](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/pipeline_name_conventions) - Naming does not adhere to nf-core conventions: Contains non alphanumeric characters
* [schema_lint](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/schema_lint) - Input mimetype is missing or empty

### :grey_question: Tests ignored:

* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `assets/nf-core-sceptre-pipeline_logo_light.png`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `docs/images/nf-core-sceptre-pipeline_logo_light.png`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `docs/images/nf-core-sceptre-pipeline_logo_dark.png`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `.github/workflows/branch.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `.github/actions/get-shards/action.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `.github/actions/nf-test/action.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `.github/workflows/pr-comment.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `assets/email_template.html`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `assets/email_template.txt`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `assets/sendmail_template.txt`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `assets/multiqc_config.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `conf/igenomes.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `conf/igenomes_ignored.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `.github/workflows/awstest.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `.github/workflows/awsfulltest.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File is ignored: `.github/.dockstore.yml`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable ignored: `manifest.name`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable ignored: `manifest.homePage`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `.gitattributes`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `CODE_OF_CONDUCT.md`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `LICENSE` or `LICENSE.md` or `LICENCE` or `LICENCE.md`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `.github/.dockstore.yml`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `.github/ISSUE_TEMPLATE/config.yml`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `.github/PULL_REQUEST_TEMPLATE.md`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `.github/workflows/branch.yml`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `.github/workflows/pr-comment.yml`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `.github/workflows/linting.yml`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `assets/email_template.html`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `assets/email_template.txt`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `assets/sendmail_template.txt`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `assets/nf-core-sceptre-pipeline_logo_light.png`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `docs/images/nf-core-sceptre-pipeline_logo_light.png`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `docs/images/nf-core-sceptre-pipeline_logo_dark.png`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - File ignored due to lint config: `docs/README.md`
* [actions_awstest](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/actions_awstest) - 'awstest.yml' workflow not found: `/private/tmp/sceptre-pipeline-caller-owned/.github/workflows/awstest.yml`
* [template_strings](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/template_strings) - Ignoring Jinja template strings in file `/private/tmp/sceptre-pipeline-caller-owned/container/build.sh`
* [template_strings](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/template_strings) - Ignoring Jinja template strings in file `/private/tmp/sceptre-pipeline-caller-owned/website/build.py`
* [multiqc_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/multiqc_config) - multiqc_config

### :grey_question: Tests fixed:

* [rocrate_readme_sync](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/rocrate_readme_sync) - Fixed: add the same description from `README.md` to the RO-Crate metadata.

### :white_check_mark: Tests passed:

* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.gitattributes`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.gitignore`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.nf-core.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.prettierignore`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.prettierrc.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `CHANGELOG.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `CITATIONS.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `CODE_OF_CONDUCT.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `LICENSE` or `LICENSE.md` or `LICENCE` or `LICENCE.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `nextflow_schema.json`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `nextflow.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `README.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.github/ISSUE_TEMPLATE/bug_report.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.github/ISSUE_TEMPLATE/config.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.github/ISSUE_TEMPLATE/feature_request.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.github/PULL_REQUEST_TEMPLATE.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.github/workflows/nf-test.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `.github/workflows/linting.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `conf/modules.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `conf/test.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `conf/test_full.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `docs/CONTRIBUTING.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `docs/output.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `docs/README.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `docs/README.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `docs/usage.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `nf-test.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `tests/default.nf.test`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `main.nf`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `conf/base.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `modules.json`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File found: `ro-crate-metadata.json`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `.github/ISSUE_TEMPLATE/bug_report.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `.github/ISSUE_TEMPLATE/feature_request.md`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `.github/workflows/push_dockerhub.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `.markdownlint.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `.nf-core.yaml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `.yamllint.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `bin/markdown_to_html.r`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `conf/aws.config`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `docs/images/nf-core-sceptre-pipeline_logo.png`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `lib/Checks.groovy`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `lib/Completion.groovy`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `lib/NfcoreTemplate.groovy`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `lib/Utils.groovy`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `lib/Workflow.groovy`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `lib/WorkflowMain.groovy`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `lib/WorkflowSceptre-pipeline.groovy`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `parameters.settings.json`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `pipeline_template.yml`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `Singularity`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `lib/nfcore_external_java_deps.jar`
* [files_exist](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_exist) - File not found check: `.travis.yml`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Found nf-schema plugin
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `manifest.nextflowVersion`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `manifest.description`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `manifest.version`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `timeline.enabled`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `trace.enabled`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `report.enabled`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `dag.enabled`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `process.cpus`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `process.memory`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `process.time`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `params.outdir`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `params.input`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `manifest.mainScript`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `manifest.diagram`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `timeline.file`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `trace.file`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `report.file`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable found: `dag.file`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.nf_required_version`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.container`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.singleEnd`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.igenomesIgnore`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.name`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.enable_conda`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.max_cpus`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.max_memory`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.max_time`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.validationFailUnrecognisedParams`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.validationLenientMode`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.validationSchemaIgnoreParams`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `params.validationShowHiddenParams`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `validation.failUnrecognisedParams`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable (correctly) not found: `validation.failUnrecognisedHeaders`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config ``timeline.enabled`` had correct value: ``True``
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config ``report.enabled`` had correct value: ``True``
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config ``trace.enabled`` had correct value: ``True``
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config ``dag.enabled`` had correct value: ``True``
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config ``dag.file`` ended with ``.html``
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config ``manifest.diagram`` file found: ``docs/images/workflow.svg``
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config variable ``manifest.nextflowVersion`` started with >= or !>=
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config ``manifest.version`` ends in ``dev``: ``2.0.0-dev``
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - nextflow.config contains configuration profile `test`
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.outdir= results
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.analyses= calibration,power,discovery
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.stop_after= analysis
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.checkpoint_stage= input
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.seed= 271828
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.execution_mode= reference
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.n_work_units= 4
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.array_size= 100
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.worker_arrays= false
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.help= false
* [nextflow_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nextflow_config) - Config default value correct: params.test_data= false
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' snapshots a 'versions.yml' file
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/default.nf.test' snapshots a 'versions.yml' file
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/conformance.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/conformance.nf.test' snapshots a 'versions.yml' file
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/conformance.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/conformance.nf.test' contains `outdir` parameter
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/nextflow.config' contains `modules_testdata_base_path`
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'tests/nextflow.config' contains `pipelines_testdata_base_path`
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'nf-test.config' sets a `testsDir`
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'nf-test.config' sets a `workDir`
* [nf_test_content](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nf_test_content) - 'nf-test.config' sets a `configFile`
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - `.prettierrc.yml` matches the template
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - `.github/ISSUE_TEMPLATE/bug_report.yml` matches the template
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - `.github/ISSUE_TEMPLATE/feature_request.yml` matches the template
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - `.gitignore` matches the template
* [files_unchanged](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/files_unchanged) - `.prettierignore` matches the template
* [actions_nf_test](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/actions_nf_test) - '.github/workflows/nf-test.yml' is triggered on expected events
* [actions_nf_test](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/actions_nf_test) - '.github/workflows/nf-test.yml' checks minimum NF version
* [readme](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/readme) - README Nextflow minimum version badge matched config. Badge: `25.10.4`, Config: `25.10.4`
* [readme](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/readme) - README Zenodo placeholder was replaced with DOI.
* [pipeline_todos](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/pipeline_todos) - No TODO strings found
* [pipeline_if_empty_null](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/pipeline_if_empty_null) - No `ifEmpty(null)` strings found
* [plugin_includes](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/plugin_includes) - No wrong validation plugin imports have been found
* [template_strings](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/template_strings) - Did not find any Jinja template strings (0 files)
* [schema_lint](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/schema_lint) - Schema lint passed
* [schema_lint](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/schema_lint) - Schema title + description lint passed
* [schema_params](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/schema_params) - Schema matched params returned from nextflow config
* [system_exit](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/system_exit) - No `System.exit` calls found
* [actions_schema_validation](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/actions_schema_validation) - Workflow validation passed: publish-container.yml
* [actions_schema_validation](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/actions_schema_validation) - Workflow validation passed: nf-test.yml
* [actions_schema_validation](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/actions_schema_validation) - Workflow validation passed: linting.yml
* [merge_markers](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/merge_markers) - No merge markers found in pipeline files
* [modules_structure](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/modules_structure) - modules directory structure is correct 'modules/nf-core/TOOL/SUBTOOL'
* [local_component_structure](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/local_component_structure) - local subworkflows directory structure is correct 'subworkflows/local/TOOL/SUBTOOL'
* [base_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/base_config) - `conf/base.config` found and not ignored.
* [modules_config](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/modules_config) - `conf/modules.config` found and not ignored.
* [nfcore_yml](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nfcore_yml) - Repository type in `.nf-core.yml` is valid: `pipeline`
* [nfcore_yml](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/nfcore_yml) - nf-core version in `.nf-core.yml` is set to the latest version: `4.2.0`
* [rocrate_readme_sync](https://nf-co.re/docs/nf-core-tools/api_reference/4.2.0/pipeline_lint_tests/rocrate_readme_sync) - RO-Crate descriptions are in sync with `README.md`.

### Run details

* nf-core/tools version 4.2.0
* Run at `2026-10-23 01:25:44`

</details>
