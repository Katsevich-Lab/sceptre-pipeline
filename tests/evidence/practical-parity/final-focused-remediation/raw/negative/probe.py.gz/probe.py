import hashlib,json,os,pathlib,shutil,subprocess
repo=pathlib.Path('/Users/ekatsevi/Documents/Codex/2026-10-22/new-realtime-voice-chat-6/sceptre-pipeline-parity')
probe=pathlib.Path('/tmp/sceptre-demo-caller-oracle')
image='sha256:b51c1cdaef908f6386b3313bd787f5d46dcc7b3f08c5fe28b271d2e5c85cd6c9'
base=['docker','run','--rm','--user',f'{os.getuid()}:{os.getgid()}','-e','HOME=/tmp','-e','R_LIBS_USER=/nonexistent','-v',f'{repo}:{repo}','-v','/tmp:/tmp','-w',str(repo),image,'Rscript','--vanilla']
results=[]
for version in ('25.10.4','26.10.3'):
    run=pathlib.Path('/tmp/sceptre-demo-caller-'+version)
    original=subprocess.run(base+[str(probe/'original-check.R'),str(run)],capture_output=True,text=True)
    (probe/(version+'-original-oracle.log')).write_text(original.stdout+original.stderr)
    assert original.returncode!=0 and 'identical(report$provenance$manifest$package, lock)' in original.stderr
    results.append(dict(version=version,case='original-stale-preview-equals-full-lock',exit=original.returncode,expected_rejection=True))
    for case,code,diagnostic in [
      ('full-identity-beyond-preview', "p<-file.path(commandArgs(TRUE)[1],'results/exports/scientific-report/manifest.rds'); x<-readRDS(p); stopifnot(length(x$package$dependencies)>12L); x$package$dependencies[13L]<-'CORRUPTED-VERSION'; saveRDS(x,p)", 'identical(manifest$package, lock)'),
      ('bounded-preview-identity', "p<-file.path(commandArgs(TRUE)[1],'results/exports/scientific-report/report-data.rds'); x<-readRDS(p); x$provenance$manifest$package$version<-'CORRUPTED-VERSION'; saveRDS(x,p)", 'identical(report$provenance$manifest, report_preview(manifest))')]:
        clone=probe/(version+'-'+case)
        clone.mkdir()
        for part in ('fixture','results'):shutil.copytree(run/part,clone/part)
        shutil.copy2(run/'demo-receipt.json',clone/'demo-receipt.json')
        subprocess.run(base+['-e',code,str(clone)],check=True,capture_output=True,text=True)
        result=subprocess.run(base+['demo/check-output.R',str(clone)],capture_output=True,text=True)
        (probe/(version+'-'+case+'.log')).write_text(result.stdout+result.stderr)
        assert result.returncode!=0 and diagnostic in result.stderr,(version,case,result.stderr)
        results.append(dict(version=version,case=case,exit=result.returncode,expected_rejection=True))
(probe/'negative-results.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS all six actual stale-oracle/full-identity/preview-negative probes; original runs untouched')
