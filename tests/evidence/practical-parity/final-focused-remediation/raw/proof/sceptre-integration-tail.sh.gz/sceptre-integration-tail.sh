#!/usr/bin/env bash
set -euo pipefail
# Run from repository root with exact isolated R_LIBS (or inside qualified image).
root=$(pwd)
run_dir=${1:?Usage: tests/run-nextflow.sh NEW_RUN_DIRECTORY}
mkdir -p "$run_dir"
run_dir=$(cd "$run_dir" && pwd)
run_r() {
  if [[ -n "${SCEPTRE_CONTAINER_IMAGE:-}" ]]; then
    docker run --rm -v "$root:$root" -v "$run_dir:$run_dir" -w "$root" "$SCEPTRE_CONTAINER_IMAGE" Rscript --vanilla "$@"
  else
    Rscript --vanilla "$@"
  fi
}
profile=test
if [[ -n "${SCEPTRE_CONTAINER_IMAGE:-}" ]]; then profile=test,docker; fi
args=(run "$root/main.nf" -c "$run_dir/site/site.config" -profile "$profile" -ansi-log false -work-dir "$run_dir/work"
  --input_bundle "$run_dir/fixture/input" --analysis_config "$run_dir/fixture/config.rds"
  --environment_lock "$run_dir/fixture/lock.rds" --outdir "$run_dir/results"
  --execution_mode "${SCEPTRE_EXECUTION_MODE:-reference}" --n_work_units 3)
if [[ -n "${SCEPTRE_CONTAINER_IMAGE:-}" ]]; then
  args+=( --container_image "$SCEPTRE_CONTAINER_IMAGE" )
fi
resume_id=$(run_r -e 'cat(readRDS(commandArgs(TRUE)[1])$options$session_id)' "$run_dir/results/run_signature.rds")
# A different .nf implementation must not inherit old published state on resume.
python3 - "$root" "$run_dir/altered-source" <<'PY_SOURCE'
import pathlib,shutil,sys,hashlib,json
src,dst=map(pathlib.Path,sys.argv[1:]); dst.mkdir()
for folder in ('bin','conf','modules','subworkflows','resources','demo'):
    shutil.copytree(src/folder,dst/folder)
for name in ('main.nf','nextflow.config','nextflow_schema.json'):
    shutil.copyfile(src/name,dst/name)
before=hashlib.sha256((dst/'main.nf').read_bytes()).hexdigest()
with (dst/'main.nf').open('a') as f: f.write('\n// altered-source resume rejection fixture\n')
after=hashlib.sha256((dst/'main.nf').read_bytes()).hexdigest()
assert before!=after
(dst/'source-change.json').write_text(json.dumps({'before':before,'after':after})+'\n')
PY_SOURCE
altered_args=("${args[@]}")
altered_args[1]="$run_dir/altered-source/main.nf"
if (cd "$run_dir" && nextflow "${altered_args[@]}" -resume "$resume_id") > "$run_dir/altered-source.log" 2>&1; then
  echo 'Altered workflow source resumed into stale publication paths' >&2; exit 1
fi
grep -q 'Output directory belongs to a different run' "$run_dir/altered-source.log"
echo 'PASS altered .nf source resume rejected; original source identical resume passed'

if [[ "${SCEPTRE_EXECUTION_MODE:-reference}" == distributed ]]; then
  failure_args=(run "$root/main.nf" -c "$root/tests/conf/worker-failure.config"
    -profile "$profile" -ansi-log false -work-dir "$run_dir/failure-work"
    --input_bundle "$run_dir/fixture/input" --analysis_config "$run_dir/fixture/config.rds"
    --environment_lock "$run_dir/fixture/lock.rds" --outdir "$run_dir/failure-results"
    --execution_mode distributed --n_work_units 3 --analyses discovery)
  if [[ -n "${SCEPTRE_CONTAINER_IMAGE:-}" ]]; then
    failure_args+=(--container_image "$SCEPTRE_CONTAINER_IMAGE")
  fi
  if (cd "$run_dir" && nextflow "${failure_args[@]}") > "$run_dir/worker-failure.log" 2>&1; then
    echo 'Worker failure unexpectedly succeeded' >&2; exit 1
  fi
  grep -q CERTIFIED_WORKER_FAILURE_TEST "$run_dir/worker-failure.log"
  test ! -d "$run_dir/failure-results/discovery/state"
  if grep -q 'Submitted process.*SCEPTRE_COLLECT' "$run_dir/worker-failure.log"; then
    echo 'Collector launched after a worker failure' >&2; exit 1
  fi
  echo 'PASS actual failed worker prevents collection and completed family publication'
fi

run_r tests/ci/check-missing-family.R "$run_dir/fixture" "$run_dir/results" "$run_dir/missing-family"
